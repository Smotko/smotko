﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AbsoluteRead
{
    public static class Test
    {
        public static string TestString()
        {
            return "It works!";
        }
        public static string TestStringArg(string str) 
        {
            return str;
        }
    }
}
