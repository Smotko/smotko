﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestAbsoluteRead
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(AbsoluteRead.Test.TestString());
            Console.WriteLine(AbsoluteRead.Test.TestStringArg("Test"));
            Console.ReadLine();
        }
    }
}
