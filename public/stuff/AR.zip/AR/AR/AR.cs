﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;


        
    public class AR
    {
        ////////////////////////////////////////////////////////////////////////////
        ////
        //// AR Device
        ////
        ////////////////////////////////////////////////////////////////////////////

        //const char * __stdcall                    ARGetSDKVersion();
        [DllImport("absoluteread.dll")]
        private static extern string ARGetSDKVersion();
        //EResult __stdcall                         ARDeviceOpen();
        [DllImport("absoluteread.dll")]
        private static extern long ARDeviceOpen();
        //EResult __stdcall                         ARDeviceClose();
        [DllImport("absoluteread.dll")]
        private static extern long ARDeviceClose();
        //EResult __stdcall                         ARSetDebug(const char *filename);
        [DllImport("absoluteread.dll")]
        private static extern long ARSetDebug(string filename);
        //EARDeviceStatus __stdcall                 ARDeviceGetStatus();

        //EResult __stdcall                         ARDeviceGet(EDeviceData type, const char **data);
        //EResult __stdcall                         ARDeviceGetSC(EDeviceData type, char *data, int size);
        //EResult __stdcall                         ARDeviceGetInt(EDeviceData type, int *data);
        //EResult __stdcall                         ARDeviceGetDate(EDeviceData type, int *year, int *month, int *day);

        ////////////////////////////////////////////////////////////////////////////
        ////
        //// AR Document Create
        ////
        ////////////////////////////////////////////////////////////////////////////

        //EResult __stdcall                         ARDocumentClear();
        [DllImport("absoluteread.dll")]
        private static extern long ARDocumentClear();
        //EResult __stdcall                         ARDocumentPrepare();
        [DllImport("absoluteread.dll")]
        private static extern long ARDocumentPrepare();
        //EResult __stdcall                         ARDocumentDone();
        [DllImport("absoluteread.dll")]
        private static extern long ARDocumentDone();
        //EResult __stdcall                         ARDocumentGetStats(int *datasize, int *datasizecomp, int *datalastcodeleft);
        ////
        //EResult __stdcall                         ARDocumentGetCodeCount(int *num);
        //EResult __stdcall                         ARDocumentGetCode(int index, void *image, int *width);
        ////
        //EResult __stdcall                         ARDocumentSetCSV(const char *data);
        [DllImport("absoluteread.dll")]
        private static extern long ARDocumentSetCSV(string data);
        //EResult __stdcall                         ARDocumentSet(EDocumentData type, const char *data);
        //EResult __stdcall                         ARDocumentSetInt(EDocumentData type, int data);
        //EResult __stdcall                         ARDocumentSetDouble(EDocumentData type, double data);
        //EResult __stdcall                         ARDocumentSetDate(EDocumentData type, int year, int month, int day);
        ////
        //EResult __stdcall                         ARDocumentSetInvoicee(EDocumentCompanyData type, const char *data);
        //EResult __stdcall                         ARDocumentSetInvoiceeInt(EDocumentCompanyData type, int data);
        ////
        //EResult __stdcall                         ARDocumentSetCustomer(EDocumentCompanyData type, const char *data);
        ////
        //EResult __stdcall                         ARDocumentAddItem(); 
        //EResult __stdcall                         ARDocumentGetItemCount(int *count); 
        //EResult __stdcall                         ARDocumentSetItemIndex(int index); 
        ////
        //EResult __stdcall                         ARDocumentSetItem(EDocumentItemData type, const char *data);
        //EResult __stdcall                         ARDocumentSetItemInt(EDocumentItemData type, int data);
        //EResult __stdcall                         ARDocumentSetItemDouble(EDocumentItemData type, double data);
        //EResult __stdcall                         ARDocumentSetItemDate(EDocumentItemData type, int year, int month, int day);

        ////////////////////////////////////////////////////////////////////////////
        ////
        //// AR Document Scan
        ////
        ////////////////////////////////////////////////////////////////////////////

        //EResult __stdcall                         ARDocumentScan();
        [DllImport("absoluteread.dll")]
        private static extern long ARDocumentScan();
        //EResult __stdcall                         ARDocumentScanThread();
        //EResult __stdcall                         ARDocumentTest(int idx);
        ////
        //EResult __stdcall                         ARDocumentScanSimulate(const char *data);
        ////
        //EResult __stdcall                         ARDocumentGetCSV(const char **data);
        [DllImport("absoluteread.dll")]
        private static extern long ARDocumentGetCSV(ref string data);
        //EResult __stdcall                         ARDocumentSaveCSV(const char *filename);
        [DllImport("absoluteread.dll")]
        private static extern long ARDocumentSaveCSV(string filename);
        //EResult __stdcall                         ARDocumentGet(EDocumentData type, const char **data);
        //EResult __stdcall                         ARDocumentGetSC(EDocumentData type, char *data, int size);
        //EResult __stdcall                         ARDocumentGetInt(EDocumentData type, int *data);
        //EResult __stdcall                         ARDocumentGetDouble(EDocumentData type, double *data);
        //EResult __stdcall                         ARDocumentGetDate(EDocumentData type, int *year, int *month, int *day);
        ////
        //EResult __stdcall                         ARDocumentGetInvoicee(EDocumentCompanyData type, const char **data);
        //EResult __stdcall                         ARDocumentGetInvoiceeSC(EDocumentCompanyData type, char *data, int size);
        //EResult __stdcall                         ARDocumentGetInvoiceeInt(EDocumentCompanyData type, int *data);
        ////
        //EResult __stdcall                         ARDocumentGetCustomer(EDocumentCompanyData type, const char **data);
        //EResult __stdcall                         ARDocumentGetCustomerSC(EDocumentCompanyData type, char *data, int size);
        ////
        //EResult __stdcall                         ARDocumentGetItem(EDocumentItemData type, const char **data);
        //EResult __stdcall                         ARDocumentGetItemSC(EDocumentItemData type, char *data, int size);
        //EResult __stdcall                         ARDocumentGetItemInt(EDocumentItemData type, int *data);
        //EResult __stdcall                         ARDocumentGetItemDouble(EDocumentItemData type, double *data);
        //EResult __stdcall                         ARDocumentGetItemDate(EDocumentItemData type, int *year, int *month, int *day);

        //EResult __stdcall                         ARDocumentSaveCode(int index, const char *filename, EImageFileType filetype);
        //EResult __stdcall                         ARDocumentSaveCodes(int x, int y, const char *filename, EImageFileType filetype);
        [DllImport("absoluteread.dll")]
        private static extern long ARDocumentSaveCodes(int x, int y, string name, long type);
        //EResult __stdcall                         ARDocumentGetBitmap(int index, int *handle);

        ////////////////////////////////////////////////////////////////////////////
        ////
        //// AR Misc
        ////
        ////////////////////////////////////////////////////////////////////////////

        //EResult __stdcall                         ARControlPanel();
        ////
        //void __stdcall                            ARSetCallback(TDeviceCallback callback);
        //void __stdcall                            ARSetCallbackImage(TDisplayImageCallback callback);

        //#endif

        public static string DeviceOpen()
        {
            return ARDeviceOpen().ToString();
        }
        public static string DeviceScan()
        {
            return ARDocumentScan().ToString();
        }
        public static string DocumentGetCSV(ref string data)
        {
            return ARDocumentGetCSV(ref data).ToString();
        }
        public static string DocumentSaveCSV(string filename)
        {
            return ARDocumentSaveCSV(filename).ToString();
        }
        public static string DocumentDone()
        {
            return ARDocumentDone().ToString();
        }
        public static string DocumentClear()
        {
            return ARDocumentClear().ToString();
        }
        public static string DocumentSetCSV(string data)
        {
            return ARDocumentSetCSV(data).ToString();
        }
        public static string DocumentPrepare()
        {
            return ARDocumentPrepare().ToString();
        }
        public static string DocumentSaveCodes(string x, string y, string name, string type)
        {
            return ARDocumentSaveCodes(int.Parse(x), int.Parse(y), name, int.Parse(type)).ToString();
        }
        public static string SetDebug(string filename)
        {
            return ARSetDebug(filename).ToString();
        }
    }

