﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.IO;



namespace CarpeDiem
{
    class Program
    {
        static void Main(string[] args)
        {
            AR.SetDebug("debugoutput.txt");
            AR.DocumentClear();
            AR.DocumentSetCSV(
@"document,0,ddType,int,2
document,0,ddAmount,double,24.994600
document,0,ddDocumentDate,date,2010-01-01
document,0,ddServiceDate,date,2010-01-01
document,0,ddType,int,2
document,0,ddNumber,string,""OK 10010001""
document,0,ddCurency,int,978
document,0,ddItems,int,4
customer,0,dcdName,string,""Trgovina d.o.o.""
customer,0,dcdStreet,string,""Stegne 1A""
customer,0,dcdCity,string,""Ljubljana""
customer,0,dcdCountry,string,""SLOVENIJA""
customer,0,dcdPostalCode,string,""1000""
customer,0,dcdVATId,string,""SI12345678""
invoicee,0,dcdName,string,""Kmetijska zadruga Metlika z.o.o.""
invoicee,0,dcdStreet,string,""Cesta XV. Brigade 2""
invoicee,0,dcdCity,string,""Metlika""
invoicee,0,dcdCountry,string,""SLOVENIJA""
invoicee,0,dcdTelephone,string,""07 363 70 00""
invoicee,0,dcdFax,string,""07 363 70 11""
invoicee,0,dcdEMail,string,""m.kzmetlika@siol.net""
invoicee,0,dcdWebPage,string,""http://www.kz-metlika.si/""
invoicee,0,dcdVATId,string,""SI36614882""
invoicee,0,dcdBankAccountType1,int,1
invoicee,0,dcdBankAccount1,string,""029940016851866""
invoicee,0,dcdSpecial3,int,0
invoicee,0,dcdSpecial4,int,0
item,0,didID,string,""3838606006617""
item,0,didName,string,""Moka pšen. T500 Mercator vreč. 1kg""
item,0,didLevel,int,0
item,0,didPrice,double,0.553000
item,0,didAmount,double,30.000000
item,0,didPacking,double,10.000000
item,0,didUnit,int,1
item,0,didVAT,double,8.500000
item,0,didDiscount,double,6.000000
item,0,didReferenceDocumentType,int,9
item,0,didReferenceDocumentName,string,""NK 10008813""");
            AR.DocumentPrepare();
            AR.DocumentSaveCodes("0", "0", @"test.png", "2");
            AR.DocumentDone();
            Console.Read();
        }
    }
}
